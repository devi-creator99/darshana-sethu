function sendBooking(){
const n=name.value,p=phone.value,pu=pickup.value,d=drop.value;
if(!n||!p||!pu||!d){alert("Fill all details");return;}
const msg=`🚖 Darshana Sethu Cab Booking

Name: ${n}
Phone: ${p}
Pickup: ${pu}
Drop: ${d}`;
window.open("https://wa.me/919491172851?text="+encodeURIComponent(msg),"_blank");
}